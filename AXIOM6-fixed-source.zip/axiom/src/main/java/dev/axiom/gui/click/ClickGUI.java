package dev.axiom.gui.click;

import dev.axiom.core.config.ConfigManager;
import dev.axiom.core.config.Setting;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import dev.axiom.core.module.ModuleManager;
import dev.axiom.core.util.RenderUtil;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * AXIOM ClickGUI — opened with INSERT (bound in AxiomClient).
 *
 * Layout: one panel per category, draggable, left-click to toggle module,
 * right-click to expand settings panel.
 */
public class ClickGUI extends Screen {

    // ── Panel state ───────────────────────────────────────────────────────────
    private static final int PANEL_W   = 140;
    private static final int HEADER_H  = 14;
    private static final int MODULE_H  = 11;
    private static final int SETTING_H = 11;

    private static final int COL_BG       = 0xCC111111;
    private static final int COL_HEADER   = 0xFF1A2744;
    private static final int COL_ACCENT   = 0xFF4488FF;
    private static final int COL_ON       = 0xFF44FF88;
    private static final int COL_OFF      = 0xFF555555;
    private static final int COL_TEXT     = 0xFFEEEEEE;
    private static final int COL_SUBTEXT  = 0xFFAAAAAA;

    private final Map<ModuleCategory, PanelState> panels = new EnumMap<>(ModuleCategory.class);
    private Setting<?> draggingSlider;
    private int sliderX;
    private int sliderWidth;

    public ClickGUI() {
        super(Component.literal("AXIOM"));
        int x = 4;
        for (ModuleCategory cat : ModuleCategory.values()) {
            panels.put(cat, new PanelState(x, 4));
            x += PANEL_W + 4;
        }
    }

    // ── Screen lifecycle ──────────────────────────────────────────────────────

    @Override
    public boolean isPauseScreen() { return false; }

    @Override
    public void render(GuiGraphics gg, int mouseX, int mouseY, float partialTick) {
        // Dim background
        gg.fill(0, 0, width, height, 0x88000000);
        super.render(gg, mouseX, mouseY, partialTick);

        for (ModuleCategory cat : ModuleCategory.values()) {
            drawPanel(gg, cat, mouseX, mouseY);
        }
    }

    private void drawPanel(GuiGraphics gg, ModuleCategory cat, int mx, int my) {
        PanelState state = panels.get(cat);
        List<ModuleBase> modules = ModuleManager.getInstance().getByCategory(cat);

        int px = state.x, py = state.y;
        int panelH = HEADER_H;
        for (ModuleBase m : modules) {
            panelH += MODULE_H;
            if (state.expanded(m)) {
                panelH += m.getSettings().size() * SETTING_H + 2;
            }
        }

        // Panel background
        RenderUtil.drawRect(gg, px, py, PANEL_W, panelH, COL_BG);
        RenderUtil.drawBorder(gg, px, py, PANEL_W, panelH, COL_ACCENT);

        // Header
        RenderUtil.drawRect(gg, px, py, PANEL_W, HEADER_H, COL_HEADER);
        RenderUtil.drawText(gg, cat.displayName, px + 4, py + 3, COL_ACCENT, true);

        int ry = py + HEADER_H;
        for (ModuleBase m : modules) {
            boolean on = m.isEnabled();
            boolean hov = mx >= px && mx < px + PANEL_W && my >= ry && my < ry + MODULE_H;

            RenderUtil.drawRect(gg, px, ry, PANEL_W, MODULE_H, hov ? 0xAA223344 : 0x00000000);
            // Enabled indicator bar
            RenderUtil.drawRect(gg, px, ry, 2, MODULE_H, on ? COL_ON : COL_OFF);
            RenderUtil.drawText(gg, m.getName(), px + 6, ry + 2, on ? COL_TEXT : COL_OFF, false);

            ry += MODULE_H;

            if (state.expanded(m)) {
                for (Setting<?> s : m.getSettings()) {
                    drawSetting(gg, s, px + 4, ry, PANEL_W - 4);
                    ry += SETTING_H;
                }
                ry += 2;
            }
        }
    }

    private void drawSetting(GuiGraphics gg, Setting<?> s, int x, int y, int w) {
        String label  = s.getName() + ": " + formatValue(s);
        int    labelW = font.width(label);
        RenderUtil.drawText(gg, label, x, y + 2, COL_SUBTEXT, false);

        // Slider for numeric settings
        if (s instanceof Setting.DoubleSetting ds) {
            double t = (ds.getValue() - ds.getMin()) / (ds.getMax() - ds.getMin());
            int barW = w - labelW - 8;
            if (barW > 20) {
                int bx = x + labelW + 4;
                RenderUtil.drawRect(gg, bx, y+3, barW, 5, 0x44FFFFFF);
                RenderUtil.drawRect(gg, bx, y+3, (int)(t * barW), 5, COL_ACCENT);
            }
        } else if (s instanceof Setting.IntSetting is) {
            double t = (double)(is.getValue() - is.getMin()) / (is.getMax() - is.getMin());
            int barW = w - labelW - 8;
            if (barW > 20) {
                int bx = x + labelW + 4;
                RenderUtil.drawRect(gg, bx, y+3, barW, 5, 0x44FFFFFF);
                RenderUtil.drawRect(gg, bx, y+3, (int)(t * barW), 5, COL_ACCENT);
            }
        }
    }

    private String formatValue(Setting<?> s) {
        Object v = s.getValue();
        if (v instanceof Boolean b) return b ? "ON" : "OFF";
        if (v instanceof Double d)  return String.format("%.2f", d);
        if (v instanceof Enum<?> e) {
            if (e instanceof Setting.Sensitivity sens) return sens.label;
            if (e instanceof Setting.Preset p)        return p.label;
            return e.name();
        }
        return String.valueOf(v);
    }

    // ── Mouse input ───────────────────────────────────────────────────────────

    // 1.21.9+: mouse callbacks take a MouseButtonEvent instead of (x, y, button).
    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x(), my = event.y();
        int button = event.button();
        for (ModuleCategory cat : ModuleCategory.values()) {
            PanelState state   = panels.get(cat);
            List<ModuleBase> modules = ModuleManager.getInstance().getByCategory(cat);
            int px = state.x, py = state.y;

            // Header drag start
            if (button == 0 && mx >= px && mx < px + PANEL_W && my >= py && my < py + HEADER_H) {
                state.dragging = true;
                state.dragOffX = (int)(mx - px);
                state.dragOffY = (int)(my - py);
                return true;
            }

            int ry = py + HEADER_H;
            for (ModuleBase m : modules) {
                if (my >= ry && my < ry + MODULE_H && mx >= px && mx < px + PANEL_W) {
                    if (button == 0) m.toggle();
                    else if (button == 1) state.toggleExpanded(m);
                    return true;
                }
                ry += MODULE_H;

                if (state.expanded(m)) {
                    for (Setting<?> s : m.getSettings()) {
                        if (my >= ry && my < ry + SETTING_H && mx >= px && mx < px + PANEL_W) {
                            handleSettingClick(s, (int)mx, (int)my, px + 4, ry, button);
                            return true;
                        }
                        ry += SETTING_H;
                    }
                    ry += 2;
                }
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        double mx = event.x(), my = event.y();
        if (draggingSlider != null) {
            updateSlider(mx);
            return true;
        }
        for (PanelState state : panels.values()) {
            if (state.dragging) {
                state.x = (int)mx - state.dragOffX;
                state.y = (int)my - state.dragOffY;
                return true;
            }
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        panels.values().forEach(p -> p.dragging = false);
        if (draggingSlider != null) {
            draggingSlider = null;
            ConfigManager.getInstance().save();
            return true;
        }
        return super.mouseReleased(event);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private void handleSettingClick(Setting<?> setting, int mx, int my, int x, int y, int button) {
        if (setting instanceof Setting.BooleanSetting booleanSetting) {
            booleanSetting.toggle();
            ConfigManager.getInstance().save();
        } else if (setting instanceof Setting.EnumSetting enumSetting) {
            enumSetting.cycleNext();
            ConfigManager.getInstance().save();
        } else if (setting instanceof Setting.IntSetting || setting instanceof Setting.DoubleSetting) {
            String label = setting.getName() + ": " + formatValue(setting);
            int barWidth = PANEL_W - 12 - font.width(label);
            if (barWidth <= 0) return;
            sliderX = x + font.width(label) + 4;
            sliderWidth = barWidth;
            draggingSlider = setting;
            updateSlider(mx);
        }
    }

    private void updateSlider(double mouseX) {
        if (draggingSlider == null || sliderWidth <= 0) return;
        double progress = Math.max(0.0, Math.min(1.0, (mouseX - sliderX) / sliderWidth));
        if (draggingSlider instanceof Setting.IntSetting setting) {
            int value = setting.getMin() + (int)Math.round(progress * (setting.getMax() - setting.getMin()));
            setting.setValue(value);
        } else if (draggingSlider instanceof Setting.DoubleSetting setting) {
            double value = setting.getMin() + progress * (setting.getMax() - setting.getMin());
            setting.setValue(value);
        }
    }

    // ── Panel state ───────────────────────────────────────────────────────────

    private static class PanelState {
        int x, y;
        boolean dragging   = false;
        int     dragOffX   = 0, dragOffY = 0;
        final java.util.Set<String> expandedModules = new java.util.HashSet<>();

        PanelState(int x, int y) { this.x = x; this.y = y; }

        boolean expanded(ModuleBase m)     { return expandedModules.contains(m.getName()); }
        void    toggleExpanded(ModuleBase m) {
            if (!expandedModules.remove(m.getName())) expandedModules.add(m.getName());
        }
    }
}
