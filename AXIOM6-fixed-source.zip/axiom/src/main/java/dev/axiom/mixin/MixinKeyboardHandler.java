package dev.axiom.mixin;

import dev.axiom.client.AxiomClient;
import dev.axiom.core.event.events.EventKey;
import dev.axiom.core.module.ModuleManager;
import net.minecraft.client.KeyboardHandler;
import net.minecraft.client.input.KeyEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardHandler.class)
public class MixinKeyboardHandler {

    // 1.21.9+: keyPress(long window, int action, KeyEvent event)
    @Inject(method = "keyPress", at = @At("HEAD"), cancellable = true)
    private void axiom$onKeyPress(long windowPtr, int action, KeyEvent event, CallbackInfo ci) {
        EventKey e = new EventKey(event.key(), action, event.modifiers());
        AxiomClient.getEventBus().post(e);
        if (e.isCancelled()) { ci.cancel(); return; }

        if (action == org.lwjgl.glfw.GLFW.GLFW_PRESS) {
            ModuleManager.getInstance().onKey(event.key());
        }
    }
}
