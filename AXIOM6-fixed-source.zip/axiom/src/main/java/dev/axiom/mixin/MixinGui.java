package dev.axiom.mixin;

import dev.axiom.client.AxiomClient;
import dev.axiom.core.event.events.EventRender2D;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Fires EventRender2D at the end of the in-game HUD render pass. */
@Mixin(Gui.class)
public class MixinGui {

    @Inject(method = "render", at = @At("TAIL"))
    private void axiom$onRender2D(GuiGraphics guiGraphics, DeltaTracker deltaTracker, CallbackInfo ci) {
        AxiomClient.getEventBus().post(
            new EventRender2D(guiGraphics, deltaTracker.getGameTimeDeltaPartialTick(false)));
    }
}
