package dev.axiom.mixin;

import dev.axiom.core.module.ModuleManager;
import dev.axiom.modules.render.FreeLook;
import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class MixinCamera {

    // Read the camera's stored rotation directly: the Camera getters were renamed
    // to record-style accessors in 1.21.11, but the backing fields are stable.
    @Shadow private float xRot;
    @Shadow private float yRot;

    @Shadow protected abstract void setRotation(float yRot, float xRot);

    @Inject(method = "setup", at = @At("TAIL"))
    private void axiom$onSetupPost(Level level, Entity entity,
                                   boolean detached, boolean mirror,
                                   float partialTick, CallbackInfo ci) {
        FreeLook fl = ModuleManager.getInstance().getModule(FreeLook.class);
        if (fl == null || !fl.isEnabled() || !fl.isHeld()) return;

        // Apply free-look offsets on top of the normal yaw/pitch
        setRotation(this.yRot + fl.getYawOffset(), this.xRot + fl.getPitchOffset());
    }
}
