package dev.axiom.modules.esp;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventRender3D;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import dev.axiom.core.module.ModuleManager;
import dev.axiom.core.util.RenderUtil;
import dev.axiom.modules.world.TunnelAnalyzer;
import net.minecraft.client.Minecraft;
import java.util.List;

public class TunnelESP extends ModuleBase {

    private final Setting.ColorSetting   color  = new Setting.ColorSetting("Color",  "Tunnel highlight color", 0xCC8844FF);
    private final Setting.BooleanSetting filled = new Setting.BooleanSetting("Filled", "Fill tunnel segments", true);

    public TunnelESP() {
        super("Tunnel ESP", "Visualises detected artificial tunnels", ModuleCategory.ESP);
        registerSetting(color);
        registerSetting(filled);
    }

    @Override protected void onEnable()  {}
    @Override protected void onDisable() {}

    @EventHandler
    public void onRender3D(EventRender3D e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        TunnelAnalyzer ta = ModuleManager.getInstance().getModule(TunnelAnalyzer.class);
        if (ta == null || !ta.isEnabled()) return;

        var cam = mc.gameRenderer.getMainCamera().position();
        int col = color.getEffectiveColor();

        for (List<TunnelAnalyzer.TunnelSegment> segs : ta.getTunnels()) {
            for (TunnelAnalyzer.TunnelSegment seg : segs) {
                double x1 = seg.start().getX()   - cam.x;
                double y1 = seg.start().getY()   - cam.y;
                double z1 = seg.start().getZ()   - cam.z;
                double x2 = seg.end().getX()+1   - cam.x;
                double y2 = seg.end().getY()+2   - cam.y;
                double z2 = seg.end().getZ()+1   - cam.z;
                if (filled.getValue())
                    RenderUtil.drawFilledBox(e.getPoseStack(), x1, y1, z1, x2, y2, z2, col & 0x33FFFFFF);
                RenderUtil.drawBox(e.getPoseStack(), x1, y1, z1, x2, y2, z2, col);
            }
        }
    }
}
