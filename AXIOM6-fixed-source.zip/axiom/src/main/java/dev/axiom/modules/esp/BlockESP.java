package dev.axiom.modules.esp;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventRender3D;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import dev.axiom.core.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import java.util.ArrayList;
import java.util.List;

public class BlockESP extends ModuleBase {

    private final Setting.ColorSetting   color    = new Setting.ColorSetting("Color", "Highlight color", 0xCC00FFFF);
    private final Setting.IntSetting     radius   = new Setting.IntSetting("Radius", "Search radius", 48, 8, 128);
    private final Setting.BooleanSetting obsidian = new Setting.BooleanSetting("Obsidian", "Highlight obsidian", false);
    private final Setting.BooleanSetting bedrock  = new Setting.BooleanSetting("Bedrock Gaps", "Highlight bedrock", false);
    private final Setting.BooleanSetting nether   = new Setting.BooleanSetting("Nether Blocks", "Highlight nether blocks in overworld", true);

    private final List<BlockPos> cache = new ArrayList<>();
    private int tick = 0;

    public BlockESP() {
        super("Block ESP", "Highlights specific interesting blocks", ModuleCategory.ESP);
        registerSetting(color);
        registerSetting(radius);
        registerSetting(obsidian);
        registerSetting(bedrock);
        registerSetting(nether);
    }

    @Override protected void onEnable()  { cache.clear(); }
    @Override protected void onDisable() { cache.clear(); }

    @EventHandler
    public void onRender3D(EventRender3D e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        if (++tick >= 10) {
            tick = 0;
            cache.clear();
            Level level  = mc.level;
            BlockPos center = mc.player.blockPosition();
            int r = radius.getValue();
            for (int x = center.getX() - r; x <= center.getX() + r; x += 2)
            for (int y = -64; y <= 320; y += 2)
            for (int z = center.getZ() - r; z <= center.getZ() + r; z += 2) {
                BlockPos bp = new BlockPos(x, y, z);
                if (matches(level.getBlockState(bp).getBlock())) cache.add(bp);
            }
        }

        var cam = mc.gameRenderer.getMainCamera().position();
        int col = color.getEffectiveColor();
        for (BlockPos bp : cache) {
            double ox = bp.getX() - cam.x;
            double oy = bp.getY() - cam.y;
            double oz = bp.getZ() - cam.z;
            RenderUtil.drawBox(e.getPoseStack(), ox, oy, oz, ox + 1, oy + 1, oz + 1, col);
        }
    }

    private boolean matches(Block b) {
        if (obsidian.getValue() && (b == Blocks.OBSIDIAN || b == Blocks.CRYING_OBSIDIAN)) return true;
        if (bedrock.getValue()  &&  b == Blocks.BEDROCK) return true;
        if (nether.getValue()   && (b == Blocks.NETHER_BRICKS || b == Blocks.NETHER_QUARTZ_ORE
                || b == Blocks.SOUL_SAND || b == Blocks.NETHERRACK)) return true;
        return false;
    }
}
