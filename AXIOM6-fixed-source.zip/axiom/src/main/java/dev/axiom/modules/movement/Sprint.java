package dev.axiom.modules.movement;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventTick;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec2;

public class Sprint extends ModuleBase {

    private final Setting.BooleanSetting omniSprint =
        new Setting.BooleanSetting("Omni-Sprint", "Sprint in all directions, not just forward", true);

    public Sprint() {
        super("Sprint", "Automatically sprints without holding the sprint key", ModuleCategory.MOVEMENT);
        registerSetting(omniSprint);
    }

    @Override protected void onEnable()  {}
    @Override protected void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.setSprinting(false);
    }

    @EventHandler
    public void onTick(EventTick e) {
        if (e.getPhase() != EventTick.Phase.PRE) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        if (mc.player.isInWater() || mc.player.isInLava()) return;

        // 1.21.5+: ClientInput no longer has forwardImpulse/leftImpulse fields;
        // movement is exposed as a Vec2 (x = strafe, y = forward).
        LocalPlayer lp = (LocalPlayer) mc.player;
        Vec2 move = lp.input.getMoveVector();
        boolean forward  = move.y != 0;
        boolean strafe   = move.x != 0;
        boolean moving   = forward || strafe;

        if (!moving) { mc.player.setSprinting(false); return; }

        boolean canSprint = mc.player.getFoodData().getFoodLevel() > 6
            || mc.player.getAbilities().mayfly;

        if (canSprint) {
            if (omniSprint.getValue()) mc.player.setSprinting(true);
            else if (forward)          mc.player.setSprinting(true);
        }
    }
}
