package dev.axiom.modules.world;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventChunkLoad;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import net.minecraft.world.level.ChunkPos;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class NewChunks extends ModuleBase {

    private final Setting.ColorSetting newColor  = new Setting.ColorSetting("New Chunk Color",  "Color for newly generated chunks", 0x80FF4444);
    private final Setting.ColorSetting oldColor  = new Setting.ColorSetting("Old Chunk Color",  "Color for previously loaded chunks", 0x8044FF44);
    private final Setting.BooleanSetting showOld = new Setting.BooleanSetting("Show Old Chunks","Highlight old (cached) chunks", false);
    private final Setting.BooleanSetting showNew = new Setting.BooleanSetting("Show New Chunks","Highlight freshly generated chunks", true);

    private final Set<Long> newChunks = Collections.newSetFromMap(new ConcurrentHashMap<>());
    private final Set<Long> oldChunks = Collections.newSetFromMap(new ConcurrentHashMap<>());

    public NewChunks() {
        super("New Chunks", "Highlights newly generated vs cached chunks", ModuleCategory.WORLD);
        registerSetting(newColor);
        registerSetting(oldColor);
        registerSetting(showOld);
        registerSetting(showNew);
    }

    @Override protected void onEnable()  { newChunks.clear(); oldChunks.clear(); }
    @Override protected void onDisable() { newChunks.clear(); oldChunks.clear(); }

    @EventHandler
    public void onChunkLoad(EventChunkLoad e) {
        long key = e.getChunk().getPos().toLong();
        boolean isNew = isNewlyGenerated(e.getChunk());
        if (isNew) newChunks.add(key);
        else       oldChunks.add(key);
    }

    private boolean isNewlyGenerated(net.minecraft.world.level.chunk.LevelChunk chunk) {
        return chunk.getInhabitedTime() == 0;
    }

    public boolean isNew(ChunkPos pos)  { return newChunks.contains(pos.toLong()); }
    public boolean isOld(ChunkPos pos)  { return oldChunks.contains(pos.toLong()); }
    public int getNewColor()            { return newColor.getEffectiveColor(); }
    public int getOldColor()            { return oldColor.getEffectiveColor(); }
    public boolean showNew()            { return showNew.getValue(); }
    public boolean showOld()            { return showOld.getValue(); }
}
