package dev.axiom.modules.esp;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventRender2D;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import dev.axiom.core.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;

public class TargetHUD extends ModuleBase {

    private final Setting.IntSetting     posX       = new Setting.IntSetting("X", "HUD X position", 10, 0, 1920);
    private final Setting.IntSetting     posY       = new Setting.IntSetting("Y", "HUD Y position", 60, 0, 1080);
    private final Setting.BooleanSetting showHealth = new Setting.BooleanSetting("Health", "Show health bar", true);
    private final Setting.BooleanSetting showArmor  = new Setting.BooleanSetting("Armor",  "Show armor value", true);

    private Player target = null;

    public TargetHUD() {
        super("Target HUD", "Displays focused player information", ModuleCategory.ESP);
        registerSetting(posX);
        registerSetting(posY);
        registerSetting(showHealth);
        registerSetting(showArmor);
    }

    @Override protected void onEnable()  {}
    @Override protected void onDisable() { target = null; }

    @EventHandler
    public void onRender2D(EventRender2D e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        // Find nearest player
        target = null;
        double minDist = Double.MAX_VALUE;
        for (Player p : mc.level.players()) {
            if (p == mc.player) continue;
            double d = mc.player.distanceTo(p);
            if (d < minDist) { minDist = d; target = p; }
        }
        if (target == null) return;

        int px = posX.getValue(), py = posY.getValue();
        int w = 120;
        int rows = 1 + (showHealth.getValue() ? 1 : 0) + (showArmor.getValue() ? 1 : 0);
        int h = 6 + rows * 10;

        RenderUtil.drawRect(e.getGraphics(), px, py, w, h, 0xCC111111);
        RenderUtil.drawBorder(e.getGraphics(), px, py, w, h, 0xFF4488FF);

        int row = py + 4;
        RenderUtil.drawText(e.getGraphics(), target.getName().getString(), px + 4, row, 0xFFFFFFFF, true);
        row += 10;

        if (showHealth.getValue()) {
            float hp = target.getHealth(), maxHp = target.getMaxHealth();
            int barW = (int)((hp / maxHp) * 112);
            RenderUtil.drawRect(e.getGraphics(), px+4, row, 112, 6, 0x88550000);
            RenderUtil.drawRect(e.getGraphics(), px+4, row, barW, 6, 0xCCFF3333);
            RenderUtil.drawText(e.getGraphics(),
                String.format("%.1f / %.0f hp", hp, maxHp), px + 4, row, 0xFFCCCCCC, false);
            row += 10;
        }
        if (showArmor.getValue()) {
            RenderUtil.drawText(e.getGraphics(), "Armor: " + target.getArmorValue(), px + 4, row, 0xFFCCCCCC, false);
        }
    }
}
