package dev.axiom.modules.utility;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventKey;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.item.ItemStack;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

public class InventorySorter extends ModuleBase {

    private final Setting.IntSetting sortKey = new Setting.IntSetting(
        "Sort Key", "Press this key while the player inventory is open to sort", GLFW.GLFW_KEY_R, 0, 400);

    public InventorySorter() {
        super("Inventory Sorter", "Sorts inventory by item type on keypress", ModuleCategory.UTILITY);
        registerSetting(sortKey);
    }

    @Override protected void onEnable() {}
    @Override protected void onDisable() {}

    @EventHandler
    public void onKey(EventKey event) {
        if (event.getKey() != sortKey.getValue() || event.getAction() != GLFW.GLFW_PRESS) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.gameMode == null || !(mc.screen instanceof InventoryScreen)) return;
        if (mc.player.containerMenu != mc.player.inventoryMenu) return;
        sortInventory(mc);
    }

    private void sortInventory(Minecraft mc) {
        Inventory inventory = mc.player.getInventory();
        InventoryMenu menu = mc.player.inventoryMenu;
        List<String> desiredOrder = new ArrayList<>(27);

        // Sort item identifiers, then place empty slots at the end.
        for (int slot = 9; slot < 36; slot++) {
            ItemStack stack = inventory.getItem(slot);
            if (!stack.isEmpty())
                desiredOrder.add(BuiltInRegistries.ITEM.getKey(stack.getItem()).toString());
        }
        desiredOrder.sort(Comparator.naturalOrder());
        while (desiredOrder.size() < 27) desiredOrder.add(null);

        // Use normal menu clicks so inventory changes are synchronized with the server.
        for (int target = 0; target < 27; target++) {
            int targetSlot = 9 + target;
            String wanted = desiredOrder.get(target);
            String current = itemId(inventory.getItem(targetSlot));
            if (Objects.equals(current, wanted)) continue;

            int sourceSlot = -1;
            for (int candidate = target + 1; candidate < 27; candidate++) {
                if (Objects.equals(itemId(inventory.getItem(9 + candidate)), wanted)) {
                    sourceSlot = 9 + candidate;
                    break;
                }
            }
            if (sourceSlot < 0) continue;

            click(mc, menu, targetSlot);
            click(mc, menu, sourceSlot);
            click(mc, menu, targetSlot);
        }
    }

    private String itemId(ItemStack stack) {
        return stack.isEmpty() ? null : BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
    }

    private void click(Minecraft mc, InventoryMenu menu, int slot) {
        mc.gameMode.handleInventoryMouseClick(menu.containerId, slot, 0, ClickType.PICKUP, mc.player);
    }
}
