package dev.axiom.modules.esp;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventRender3D;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import dev.axiom.core.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import java.util.ArrayList;
import java.util.List;

public class HoleESP extends ModuleBase {

    private final Setting.ColorSetting   bedrockColor = new Setting.ColorSetting("Bedrock Hole", "Pure bedrock hole",       0xCC4444FF);
    private final Setting.ColorSetting   mixedColor   = new Setting.ColorSetting("Mixed Hole",   "Bedrock+obsidian hole",   0xCC44AAFF);
    private final Setting.IntSetting     radius       = new Setting.IntSetting("Radius", "Search radius", 16, 4, 32);
    private final Setting.BooleanSetting onlyBedrock  = new Setting.BooleanSetting("Only Bedrock", "Only show pure bedrock holes", false);

    private final List<HoleEntry> holes = new ArrayList<>();
    private int tick = 0;

    public HoleESP() {
        super("Hole ESP", "Highlights safe holes for crystal PvP", ModuleCategory.ESP);
        registerSetting(bedrockColor);
        registerSetting(mixedColor);
        registerSetting(radius);
        registerSetting(onlyBedrock);
    }

    @Override protected void onEnable()  { holes.clear(); }
    @Override protected void onDisable() { holes.clear(); }

    @EventHandler
    public void onRender3D(EventRender3D e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        if (++tick >= 5) { tick = 0; scan(mc); }

        var cam = mc.gameRenderer.getMainCamera().position();
        for (HoleEntry h : holes) {
            double ox = h.pos.getX() - cam.x;
            double oy = h.pos.getY() - cam.y;
            double oz = h.pos.getZ() - cam.z;
            RenderUtil.drawFilledBox(e.getPoseStack(), ox, oy, oz, ox + 1, oy + 1, oz + 1, h.color & 0x55FFFFFF);
            RenderUtil.drawBox(e.getPoseStack(), ox, oy, oz, ox + 1, oy + 1, oz + 1, h.color);
        }
    }

    private void scan(Minecraft mc) {
        holes.clear();
        Level lvl = mc.level;
        BlockPos c = mc.player.blockPosition();
        int r = radius.getValue();
        for (int x = c.getX()-r; x <= c.getX()+r; x++)
        for (int z = c.getZ()-r; z <= c.getZ()+r; z++) {
            int y = c.getY();
            BlockPos hole = new BlockPos(x, y, z);
            if (!lvl.getBlockState(hole).isAir()) continue;
            if (!lvl.getBlockState(hole.above()).isAir()) continue;

            BlockPos[] sides = { hole.north(), hole.south(), hole.east(), hole.west(), hole.below() };
            boolean allBedrock = true, allSafe = true;
            for (BlockPos s : sides) {
                var b = lvl.getBlockState(s).getBlock();
                if (b != Blocks.BEDROCK) allBedrock = false;
                if (b != Blocks.BEDROCK && b != Blocks.OBSIDIAN && b != Blocks.CRYING_OBSIDIAN) allSafe = false;
            }
            if (!allSafe) continue;
            if (allBedrock) holes.add(new HoleEntry(hole, bedrockColor.getEffectiveColor()));
            else if (!onlyBedrock.getValue()) holes.add(new HoleEntry(hole, mixedColor.getEffectiveColor()));
        }
    }

    private record HoleEntry(BlockPos pos, int color) {}
}
