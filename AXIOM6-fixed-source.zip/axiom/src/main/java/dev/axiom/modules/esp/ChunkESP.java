package dev.axiom.modules.esp;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventRender3D;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import dev.axiom.core.util.RenderUtil;
import dev.axiom.core.world.ChunkAnomaly;
import dev.axiom.core.world.ScanQueue;
import net.minecraft.client.Minecraft;

import java.util.List;

public class ChunkESP extends ModuleBase {

    private final Setting.BooleanSetting showAnom = new Setting.BooleanSetting("Anomalies",    "Highlight anomalous chunks",   true);
    private final Setting.IntSetting     height   = new Setting.IntSetting("Height", "Height of chunk outline", 32, 8, 128);

    public ChunkESP() {
        super("Chunk ESP", "Visualises chunk borders and anomalies", ModuleCategory.ESP);
        registerSetting(showAnom);
        registerSetting(height);
    }

    @Override protected void onEnable()  {}
    @Override protected void onDisable() {}

    @EventHandler
    public void onRender3D(EventRender3D e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        var cam = mc.gameRenderer.getMainCamera().position();
        int h = height.getValue();

        if (showAnom.getValue()) {
            for (List<ChunkAnomaly> list : ScanQueue.getInstance().getAllAnomalies()) {
                for (ChunkAnomaly a : list) {
                    int col = RenderUtil.confidenceColor(a.confidence);
                    double x1 = a.pos.getMinBlockX()   - cam.x;
                    double z1 = a.pos.getMinBlockZ()   - cam.z;
                    double x2 = a.pos.getMaxBlockX()+1 - cam.x;
                    double z2 = a.pos.getMaxBlockZ()+1 - cam.z;
                    double y1 = mc.player.getY() - cam.y;
                    double y2 = y1 + h;
                    RenderUtil.drawBox(e.getPoseStack(), x1, y1, z1, x2, y2, z2, col);
                }
            }
        }
    }
}
