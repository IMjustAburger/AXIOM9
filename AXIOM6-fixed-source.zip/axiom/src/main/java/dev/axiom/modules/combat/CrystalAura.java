package dev.axiom.modules.combat;

import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventTick;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.phys.AABB;

import java.util.Comparator;
import java.util.List;

public class CrystalAura extends ModuleBase {

    private final Setting.DoubleSetting  placeRange  = new Setting.DoubleSetting("Place Range", "Crystal place range",  5.0, 2.0, 8.0);
    private final Setting.DoubleSetting  breakRange  = new Setting.DoubleSetting("Break Range", "Crystal break range",  5.0, 2.0, 8.0);
    private final Setting.IntSetting     delay       = new Setting.IntSetting("Delay",          "Action delay (ms)",    50,  10, 500);
    private final Setting.BooleanSetting antiSuicide = new Setting.BooleanSetting("Anti-Suicide","Skip crystals that damage self",true);

    private long lastAction = 0;

    public CrystalAura() {
        super("Crystal Aura", "Automates end crystal combat", ModuleCategory.COMBAT);
        registerSetting(placeRange);
        registerSetting(breakRange);
        registerSetting(delay);
        registerSetting(antiSuicide);
    }

    @Override protected void onEnable()  {}
    @Override protected void onDisable() {}

    @EventHandler
    public void onTick(EventTick e) {
        if (e.getPhase() != EventTick.Phase.PRE) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        if (System.currentTimeMillis() - lastAction < delay.getValue()) return;

        // Break nearby end crystals
        AABB box = mc.player.getBoundingBox().inflate(breakRange.getValue());
        final var player = mc.player;
        final double maxDist = breakRange.getValue();
        List<EndCrystal> crystals = mc.level.getEntitiesOfClass(EndCrystal.class, box,
            (EndCrystal c) -> c.distanceTo(player) <= maxDist);

        if (!crystals.isEmpty()) {
            EndCrystal best = crystals.stream()
                .min(Comparator.comparingDouble((EndCrystal c) -> c.distanceTo(player))).orElse(null);
            if (best != null) {
                mc.gameMode.attack(mc.player, best);
                mc.player.swing(InteractionHand.MAIN_HAND);
                lastAction = System.currentTimeMillis();
            }
        }
    }
}
