package dev.axiom.modules.esp;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.axiom.core.util.RenderUtil;
import dev.axiom.core.config.Setting;
import dev.axiom.core.event.EventHandler;
import dev.axiom.core.event.events.EventRender3D;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;
import java.util.ArrayList;
import java.util.List;

public class PearlTrajectory extends ModuleBase {

    private static final double GRAVITY = 0.03;
    private static final double DRAG    = 0.99;
    private static final double SPEED   = 1.5;

    private final Setting.ColorSetting color    = new Setting.ColorSetting("Color",    "Trajectory line color", 0xCCFF8800);
    private final Setting.IntSetting   maxSteps = new Setting.IntSetting("Steps", "Simulation steps", 120, 20, 200);

    public PearlTrajectory() {
        super("Pearl Trajectory", "Simulates ender pearl throw arc", ModuleCategory.ESP);
        registerSetting(color);
        registerSetting(maxSteps);
    }

    @Override protected void onEnable()  {}
    @Override protected void onDisable() {}

    @EventHandler
    public void onRender3D(EventRender3D e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        Vec3 origin = mc.player.getEyePosition(e.getPartialTick());
        Vec3 look   = mc.player.getLookAngle().scale(SPEED);
        var  cam    = mc.gameRenderer.getMainCamera().position();

        List<Vec3> points = new ArrayList<>();
        double px = origin.x, py = origin.y, pz = origin.z;
        double vx = look.x,   vy = look.y,   vz = look.z;

        for (int i = 0; i < maxSteps.getValue(); i++) {
            vy -= GRAVITY;
            vx *= DRAG; vy *= DRAG; vz *= DRAG;
            px += vx; py += vy; pz += vz;
            points.add(new Vec3(px - cam.x, py - cam.y, pz - cam.z));
            if (mc.level.getBlockState(new BlockPos((int)px, (int)py, (int)pz)).isSolid()) break;
        }

        if (points.size() < 2) return;
        drawLine(e.getPoseStack(), points, color.getEffectiveColor());
    }

    private void drawLine(PoseStack ps, List<Vec3> pts, int argb) {
        for (int i = 0; i < pts.size() - 1; i++) {
            Vec3 p1 = pts.get(i), p2 = pts.get(i + 1);
            RenderUtil.drawLine(ps, p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, argb);
        }
    }
}
