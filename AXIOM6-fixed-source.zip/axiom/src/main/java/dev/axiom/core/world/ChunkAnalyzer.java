package dev.axiom.core.world;

import dev.axiom.core.util.BlockUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.chunk.LevelChunk;

import java.util.*;

public class ChunkAnalyzer {

    private static final double NATURAL_AIR_RATIO     = 0.08;
    private static final double EXCAVATION_AIR_RATIO  = 0.25;
    private static final int    MIN_FLAT_FLOOR_LENGTH = 6;

    private static final Set<Block> CRAFTED = Set.of(
        Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.BARREL, Blocks.SHULKER_BOX,
        Blocks.WHITE_SHULKER_BOX, Blocks.ORANGE_SHULKER_BOX, Blocks.MAGENTA_SHULKER_BOX,
        Blocks.LIGHT_BLUE_SHULKER_BOX, Blocks.YELLOW_SHULKER_BOX, Blocks.LIME_SHULKER_BOX,
        Blocks.PINK_SHULKER_BOX, Blocks.GRAY_SHULKER_BOX, Blocks.LIGHT_GRAY_SHULKER_BOX,
        Blocks.CYAN_SHULKER_BOX, Blocks.PURPLE_SHULKER_BOX, Blocks.BLUE_SHULKER_BOX,
        Blocks.BROWN_SHULKER_BOX, Blocks.GREEN_SHULKER_BOX, Blocks.RED_SHULKER_BOX,
        Blocks.BLACK_SHULKER_BOX, Blocks.FURNACE, Blocks.BLAST_FURNACE, Blocks.SMOKER,
        Blocks.CRAFTING_TABLE, Blocks.ANVIL, Blocks.CHIPPED_ANVIL, Blocks.DAMAGED_ANVIL,
        Blocks.ENCHANTING_TABLE, Blocks.BEACON, Blocks.END_PORTAL_FRAME,
        Blocks.OBSIDIAN, Blocks.CRYING_OBSIDIAN, Blocks.REINFORCED_DEEPSLATE,
        Blocks.NETHER_PORTAL, Blocks.HOPPER, Blocks.DROPPER, Blocks.DISPENSER,
        Blocks.STONECUTTER, Blocks.GRINDSTONE, Blocks.LOOM, Blocks.CARTOGRAPHY_TABLE
    );

    private static final Set<Block> ORE_BLOCKS = Set.of(
        Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE,
        Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE,
        Blocks.ANCIENT_DEBRIS
    );

    public static List<ChunkAnomaly> analyze(LevelChunk chunk, int minY, int maxY) {
        List<ChunkAnomaly> results = new ArrayList<>();
        ChunkPos cpos = chunk.getPos();
        Level level   = chunk.getLevel();

        int requestedMinY = Math.min(minY, maxY);
        int requestedMaxY = Math.max(minY, maxY);
        minY = Math.max(requestedMinY, level.getMinY());
        maxY = Math.min(requestedMaxY, level.getMaxY() - 1);
        if (minY > maxY) return results;

        int airCount       = 0;
        int totalBlocks    = 0;
        int craftedCount   = 0;
        int storageCount   = 0;
        int rareOreCount   = 0;

        for (int x = cpos.getMinBlockX(); x <= cpos.getMaxBlockX(); x++) {
            for (int z = cpos.getMinBlockZ(); z <= cpos.getMaxBlockZ(); z++) {
                for (int y = minY; y <= maxY; y++) {
                    BlockPos bp = new BlockPos(x, y, z);
                    Block b = level.getBlockState(bp).getBlock();
                    totalBlocks++;

                    if (level.getBlockState(bp).isAir()) airCount++;
                    if (CRAFTED.contains(b)) craftedCount++;
                    if (b == Blocks.CHEST || b == Blocks.BARREL ||
                        b == Blocks.TRAPPED_CHEST || b.getClass().getSimpleName().contains("ShulkerBox")) {
                        storageCount++;
                    }
                    if (ORE_BLOCKS.contains(b)) rareOreCount++;
                }
            }
        }

        if (totalBlocks == 0) return results;

        double airRatio = (double) airCount / totalBlocks;

        if (airRatio > EXCAVATION_AIR_RATIO) {
            double confidence = Math.min(1.0, (airRatio - EXCAVATION_AIR_RATIO) / 0.30 * 0.8 + 0.3);
            if (craftedCount > 0) confidence = Math.min(1.0, confidence + 0.15);
            results.add(new ChunkAnomaly(cpos, ChunkAnomaly.Type.EXCAVATION, confidence,
                String.format("%.0f%% air ratio, %d crafted blocks", airRatio*100, craftedCount)));
        }

        if (airRatio > 0.12 && airRatio < 0.28 && craftedCount < 5) {
            double confidence = 0.35 + (airRatio - 0.12) / 0.16 * 0.35;
            results.add(new ChunkAnomaly(cpos, ChunkAnomaly.Type.TUNNEL, confidence,
                String.format("%.0f%% air, tunnel-like distribution", airRatio*100)));
        }

        if (storageCount >= 4) {
            double confidence = Math.min(0.95, 0.40 + storageCount * 0.07);
            results.add(new ChunkAnomaly(cpos, ChunkAnomaly.Type.STORAGE_CLUSTER, confidence,
                storageCount + " storage containers detected"));
        }

        if (craftedCount >= 3 && storageCount < 4) {
            double confidence = Math.min(0.90, 0.30 + craftedCount * 0.08);
            results.add(new ChunkAnomaly(cpos, ChunkAnomaly.Type.RARE_BLOCKS, confidence,
                craftedCount + " crafted/rare blocks in chunk"));
        }

        if (rareOreCount >= 3) {
            double confidence = Math.min(0.75, 0.30 + rareOreCount * 0.08);
            results.add(new ChunkAnomaly(cpos, ChunkAnomaly.Type.HIGH_ORE_DENSITY, confidence,
                rareOreCount + " rare ore blocks"));
        }

        if (results.size() >= 3) {
            double maxConf = results.stream().mapToDouble(a -> a.confidence).max().orElse(0);
            results.add(new ChunkAnomaly(cpos, ChunkAnomaly.Type.COMPOSITE,
                Math.min(0.98, maxConf + 0.10),
                results.size() + " overlapping anomaly types"));
        }

        return results;
    }
}
