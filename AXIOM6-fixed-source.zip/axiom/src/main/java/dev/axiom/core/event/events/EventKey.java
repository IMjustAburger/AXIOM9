package dev.axiom.core.event.events;

import dev.axiom.core.event.Event;
import dev.axiom.core.event.ICancellable;

public class EventKey extends Event implements ICancellable {

    private final int key, action, mods;
    private boolean cancelled = false;

    public EventKey(int key, int action, int mods) {
        this.key    = key;
        this.action = action;
        this.mods   = mods;
    }

    public int getKey()    { return key; }
    public int getAction() { return action; }
    public int getMods()   { return mods; }

    @Override public boolean isCancelled()           { return cancelled; }
    @Override public void    setCancelled(boolean c) { cancelled = c; }
}
