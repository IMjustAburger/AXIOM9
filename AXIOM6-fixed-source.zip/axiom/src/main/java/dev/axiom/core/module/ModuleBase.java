package dev.axiom.core.module;

import dev.axiom.client.AxiomClient;
import dev.axiom.core.config.ConfigManager;
import dev.axiom.core.config.Setting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class ModuleBase {

    private final String         name;
    private final String         description;
    private final ModuleCategory category;

    private boolean enabled  = false;
    private int     keyBind  = -1;
    private boolean visible  = true;

    private final List<Setting<?>> settings = new ArrayList<>();

    protected ModuleBase(String name, String description, ModuleCategory category) {
        this.name        = name;
        this.description = description;
        this.category    = category;
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    public void enable() {
        if (enabled) return;
        enabled = true;
        AxiomClient.getEventBus().subscribe(this);
        onEnable();
        ConfigManager.getInstance().save();
    }

    public void disable() {
        if (!enabled) return;
        enabled = false;
        AxiomClient.getEventBus().unsubscribe(this);
        onDisable();
        ConfigManager.getInstance().save();
    }

    public void toggle() {
        if (enabled) disable(); else enable();
    }

    protected abstract void onEnable();
    protected abstract void onDisable();
    public    void          onTick()   {}

    // ── Settings ──────────────────────────────────────────────────────────────

    protected void registerSetting(Setting<?> s) { settings.add(s); }

    public List<Setting<?>> getSettings() { return Collections.unmodifiableList(settings); }

    @SuppressWarnings("unchecked")
    public <T extends Setting<?>> T getSetting(String name) {
        return (T) settings.stream().filter(s -> s.getName().equals(name)).findFirst().orElse(null);
    }

    // ── Accessors ─────────────────────────────────────────────────────────────

    public String         getName()       { return name; }
    public String         getDescription(){ return description; }
    public ModuleCategory getCategory()   { return category; }
    public boolean        isEnabled()     { return enabled; }
    public int            getKeyBind()    { return keyBind; }
    public void           setKeyBind(int k){ keyBind=k; }
    public boolean        isVisible()     { return visible; }
    public void           setVisible(boolean v){ visible=v; }
}
