package dev.axiom.core.util;
import net.minecraft.world.phys.Vec3;
public class MathUtil {
    public static double distanceTo(double x1,double y1,double z1,double x2,double y2,double z2){
        return Math.sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1)+(z2-z1)*(z2-z1));
    }
    public static double clamp(double v,double min,double max){ return Math.max(min,Math.min(max,v)); }
    public static float  clamp(float  v,float  min,float  max){ return Math.max(min,Math.min(max,v)); }
    public static int    clamp(int    v,int    min,int    max){ return Math.max(min,Math.min(max,v)); }
    public static Vec3   interpolate(Vec3 a,Vec3 b,double t){ return a.add(b.subtract(a).scale(t)); }
}
