package dev.axiom.core.event.events;
import dev.axiom.core.event.Event;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.chunk.LevelChunk;
public class EventChunkLoad extends Event {
    private final LevelChunk chunk;
    public EventChunkLoad(LevelChunk c){ chunk = c; }
    public LevelChunk getChunk(){ return chunk; }
    public ChunkPos   getPos()  { return chunk.getPos(); }
}
