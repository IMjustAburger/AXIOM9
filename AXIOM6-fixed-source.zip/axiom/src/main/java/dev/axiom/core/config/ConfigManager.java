package dev.axiom.core.config;

import com.google.gson.*;
import dev.axiom.client.AxiomClient;
import dev.axiom.core.module.ModuleBase;
import dev.axiom.core.module.ModuleManager;
import net.minecraft.client.Minecraft;

import java.io.*;
import java.nio.file.*;
import java.util.List;

/**
 * Loads and saves module settings to .minecraft/axiom/config.json
 * Format: { "ModuleName": { "enabled": true, "keyBind": -1, "SettingName": value, ... }, ... }
 */
public class ConfigManager {

    private static final ConfigManager INSTANCE = new ConfigManager();
    public static ConfigManager getInstance() { return INSTANCE; }

    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private Path configFile;
    private boolean loading;

    private ConfigManager() {}

    private Path getConfigFile() {
        if (configFile == null) {
            configFile = Minecraft.getInstance().gameDirectory.toPath()
                    .resolve("axiom").resolve("config.json");
        }
        return configFile;
    }

    public void load() {
        Path file = getConfigFile();
        if (!Files.exists(file)) { save(); return; }
        loading = true;
        try (Reader r = Files.newBufferedReader(file)) {
            JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
            for (ModuleBase module : ModuleManager.getInstance().getAll()) {
                if (!root.has(module.getName()) || !root.get(module.getName()).isJsonObject()) continue;
                JsonObject obj = root.getAsJsonObject(module.getName());
                if (obj.has("keyBind") && obj.get("keyBind").isJsonPrimitive())
                    module.setKeyBind(obj.get("keyBind").getAsInt());
                for (Setting<?> s : module.getSettings()) {
                    if (obj.has(s.getName())) applyValue(s, obj.get(s.getName()));
                }
                if (obj.has("enabled") && obj.get("enabled").isJsonPrimitive()
                        && obj.get("enabled").getAsBoolean()) module.enable();
            }
        } catch (Exception e) {
            AxiomClient.LOGGER.warn("Could not load config: {}", e.getMessage());
        } finally {
            loading = false;
        }
    }

    public void save() {
        if (loading) return;
        try {
            Path file = getConfigFile();
            Files.createDirectories(file.getParent());
            JsonObject root = new JsonObject();
            for (ModuleBase module : ModuleManager.getInstance().getAll()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("enabled", module.isEnabled());
                obj.addProperty("keyBind", module.getKeyBind());
                for (Setting<?> s : module.getSettings()) {
                    addValue(obj, s);
                }
                root.add(module.getName(), obj);
            }
            try (Writer w = Files.newBufferedWriter(file)) {
                gson.toJson(root, w);
            }
        } catch (Exception e) {
            AxiomClient.LOGGER.warn("Could not save config: {}", e.getMessage());
        }
    }

    @SuppressWarnings({"unchecked","rawtypes"})
    private void applyValue(Setting<?> s, JsonElement el) {
        try {
            if (s instanceof Setting.BooleanSetting bs) bs.setValue(el.getAsBoolean());
            else if (s instanceof Setting.IntSetting is) is.setValue(el.getAsInt());
            else if (s instanceof Setting.DoubleSetting ds) ds.setValue(el.getAsDouble());
            else if (s instanceof Setting.ColorSetting cs) cs.setValue(el.getAsInt());
            else if (s instanceof Setting.EnumSetting es) {
                String v = el.getAsString();
                for (Object c : es.getEnumClass().getEnumConstants()) {
                    if (((Enum<?>)c).name().equals(v)) { ((Setting.EnumSetting)es).setValue(c); break; }
                }
            }
        } catch (Exception ignored) {}
    }

    private void addValue(JsonObject obj, Setting<?> s) {
        Object v = s.getValue();
        if (v instanceof Boolean b)  obj.addProperty(s.getName(), b);
        else if (v instanceof Number n) obj.addProperty(s.getName(), n);
        else if (v instanceof Enum<?> e) obj.addProperty(s.getName(), e.name());
    }
}
