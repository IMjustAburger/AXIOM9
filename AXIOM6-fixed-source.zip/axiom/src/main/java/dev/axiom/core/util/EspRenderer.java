package dev.axiom.core.util;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MappableRingBuffer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

import java.util.OptionalDouble;
import java.util.OptionalInt;

/**
 * Batched, through-walls geometry renderer for 3D ESP (Minecraft 1.21.11 render-pipeline API).
 *
 * MC 1.21.5+ removed immediate-mode drawing (RenderSystem.setShader, BufferUploader,
 * GameRenderer.getPositionColorShader). Geometry is now written into a BufferBuilder
 * during the world-render event and drawn once per frame through a RenderPipeline
 * derived from the vanilla debug-filled-box pipeline with depth testing disabled.
 *
 * All input coordinates are camera-relative (modules subtract the camera position).
 * Outlines are drawn as camera-facing ribbons, so only the QUADS pipeline is needed.
 *
 * This is purely client-side drawing of data the client already holds.
 */
public final class EspRenderer {

    private static final RenderPipeline PIPELINE = RenderPipelines.register(
        RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
            .withLocation(Identifier.fromNamespaceAndPath("axiom", "pipeline/esp_through_walls"))
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .build());

    private static final ByteBufferBuilder ALLOCATOR = new ByteBufferBuilder(1 << 18);
    private static BufferBuilder     buffer;
    private static MappableRingBuffer vertexBuffer;

    private EspRenderer() {}

    /** Touch this from the mod initializer so the pipeline registers at startup. */
    public static void init() { /* class initialisation registers PIPELINE */ }

    private static BufferBuilder buf() {
        if (buffer == null) {
            buffer = new BufferBuilder(ALLOCATOR, PIPELINE.getVertexFormatMode(), PIPELINE.getVertexFormat());
        }
        return buffer;
    }

    // ── Geometry ──────────────────────────────────────────────────────────────

    public static void filledBox(Matrix4fc m, float x1, float y1, float z1,
                                 float x2, float y2, float z2, int argb) {
        float a = (argb >> 24 & 0xFF) / 255f, r = (argb >> 16 & 0xFF) / 255f,
              g = (argb >>  8 & 0xFF) / 255f, b = (argb       & 0xFF) / 255f;
        quad2(m, x1,y1,z1, x2,y1,z1, x2,y1,z2, x1,y1,z2, r,g,b,a); // bottom
        quad2(m, x1,y2,z1, x1,y2,z2, x2,y2,z2, x2,y2,z1, r,g,b,a); // top
        quad2(m, x1,y1,z1, x1,y2,z1, x2,y2,z1, x2,y1,z1, r,g,b,a); // north
        quad2(m, x1,y1,z2, x2,y1,z2, x2,y2,z2, x1,y2,z2, r,g,b,a); // south
        quad2(m, x1,y1,z1, x1,y1,z2, x1,y2,z2, x1,y2,z1, r,g,b,a); // west
        quad2(m, x2,y1,z1, x2,y2,z1, x2,y2,z2, x2,y1,z2, r,g,b,a); // east
    }

    public static void outlineBox(Matrix4fc m, float x1, float y1, float z1,
                                  float x2, float y2, float z2, int argb) {
        float[] xs = {x1, x2}, ys = {y1, y2}, zs = {z1, z2};
        for (int i = 0; i < 2; i++) for (int j = 0; j < 2; j++) {
            line(m, xs[0], ys[i], zs[j], xs[1], ys[i], zs[j], argb); // along X
            line(m, xs[i], ys[0], zs[j], xs[i], ys[1], zs[j], argb); // along Y
            line(m, xs[i], ys[j], zs[0], xs[i], ys[j], zs[1], argb); // along Z
        }
    }

    /** Camera-facing ribbon whose width grows slightly with distance so it stays visible. */
    public static void line(Matrix4fc m, float x1, float y1, float z1,
                            float x2, float y2, float z2, int argb) {
        float dx = x2 - x1, dy = y2 - y1, dz = z2 - z1;
        float mx = (x1 + x2) * 0.5f, my = (y1 + y2) * 0.5f, mz = (z1 + z2) * 0.5f; // camera is at origin
        // side = d × toMid
        float sx = dy * mz - dz * my, sy = dz * mx - dx * mz, sz = dx * my - dy * mx;
        float len = (float) Math.sqrt(sx*sx + sy*sy + sz*sz);
        if (len < 1.0e-6f) return;
        float dist = (float) Math.sqrt(mx*mx + my*my + mz*mz);
        float half = (0.012f + 0.0025f * dist) * 0.5f;
        sx = sx / len * half; sy = sy / len * half; sz = sz / len * half;
        float a = (argb >> 24 & 0xFF) / 255f, r = (argb >> 16 & 0xFF) / 255f,
              g = (argb >>  8 & 0xFF) / 255f, b = (argb       & 0xFF) / 255f;
        quad2(m, x1-sx,y1-sy,z1-sz, x1+sx,y1+sy,z1+sz, x2+sx,y2+sy,z2+sz, x2-sx,y2-sy,z2-sz, r,g,b,a);
    }

    /** Emits a quad with both windings so face culling can never hide it. */
    private static void quad2(Matrix4fc m,
            float x1,float y1,float z1, float x2,float y2,float z2,
            float x3,float y3,float z3, float x4,float y4,float z4,
            float r,float g,float b,float a) {
        BufferBuilder bb = buf();
        bb.addVertex(m,x1,y1,z1).setColor(r,g,b,a);
        bb.addVertex(m,x2,y2,z2).setColor(r,g,b,a);
        bb.addVertex(m,x3,y3,z3).setColor(r,g,b,a);
        bb.addVertex(m,x4,y4,z4).setColor(r,g,b,a);
        bb.addVertex(m,x4,y4,z4).setColor(r,g,b,a);
        bb.addVertex(m,x3,y3,z3).setColor(r,g,b,a);
        bb.addVertex(m,x2,y2,z2).setColor(r,g,b,a);
        bb.addVertex(m,x1,y1,z1).setColor(r,g,b,a);
    }

    // ── Draw ──────────────────────────────────────────────────────────────────

    /** Draws everything queued this frame. Call once after EventRender3D has been posted. */
    public static void flush() {
        BufferBuilder builder = buffer;
        buffer = null;
        if (builder == null) return;

        MeshData mesh = builder.build();
        if (mesh == null) return;

        try (mesh) {
            int size = mesh.vertexBuffer().remaining();
            if (vertexBuffer == null || vertexBuffer.size() < size) {
                if (vertexBuffer != null) vertexBuffer.close();
                vertexBuffer = new MappableRingBuffer(
                    () -> "axiom esp vertices",
                    GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_MAP_WRITE,
                    size);
            }

            CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
            try (GpuBuffer.MappedView view =
                     encoder.mapBuffer(vertexBuffer.currentBuffer().slice(0, size), false, true)) {
                MemoryUtil.memCopy(mesh.vertexBuffer(), view.data());
            }
            GpuBuffer vertices = vertexBuffer.currentBuffer();

            mesh.sortQuads(ALLOCATOR, RenderSystem.getProjectionType().vertexSorting());
            VertexFormat format = PIPELINE.getVertexFormat();
            GpuBuffer indices = format.uploadImmediateIndexBuffer(mesh.indexBuffer());
            VertexFormat.IndexType indexType = mesh.drawState().indexType();
            int indexCount = mesh.drawState().indexCount();

            GpuBufferSlice transforms = RenderSystem.getDynamicUniforms().writeTransform(
                RenderSystem.getModelViewMatrix(),
                new Vector4f(1f, 1f, 1f, 1f),
                new Vector3f(),
                new Matrix4f());

            RenderTarget target = Minecraft.getInstance().getMainRenderTarget();
            try (RenderPass pass = RenderSystem.getDevice().createCommandEncoder().createRenderPass(
                    () -> "AXIOM ESP",
                    target.getColorTextureView(), OptionalInt.empty(),
                    target.getDepthTextureView(), OptionalDouble.empty())) {
                pass.setPipeline(PIPELINE);
                RenderSystem.bindDefaultUniforms(pass);
                pass.setUniform("DynamicTransforms", transforms);
                pass.setVertexBuffer(0, vertices);
                pass.setIndexBuffer(indices, indexType);
                pass.drawIndexed(0, 0, indexCount, 1);
            }
            vertexBuffer.rotate();
        }
    }
}
