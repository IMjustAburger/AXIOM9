package dev.axiom.core.event;
public enum Priority { LOWEST, LOW, NORMAL, HIGH, HIGHEST, MONITOR }
